import glob, statistics
from collections import defaultdict

def load(tag):
    d = b''
    for f in sorted(glob.glob(f'/tmp/census/{tag}.tsv.*'), key=lambda p: int(p.split('.')[-1])):
        d += open(f, 'rb').read()
    d = d.replace(b'\r\n', b'\n').replace(b'\r', b'\n')
    raw = d.split(b'\n')
    rows = []
    i = 0
    while i < len(raw):
        line = raw[i]
        if not line.strip() and not line:
            i += 1; continue
        p = line.rsplit(b'\t', 3)
        good = False
        if len(p) == 4:
            try:
                int(p[2]); int(p[3]); good = True
            except ValueError:
                good = False
        if not good and i + 1 < len(raw):
            # value name contained a literal CR/LF: rejoin with the continuation
            merged = line + b'\n' + raw[i+1]
            p2 = merged.rsplit(b'\t', 3)
            if len(p2) == 4:
                try:
                    int(p2[2]); int(p2[3]); p = p2; good = True; i += 1
                except ValueError:
                    pass
        if not good:
            i += 1; continue
        rows.append((p[0].decode('latin-1'), p[1].decode('latin-1'), int(p[2]), int(p[3])))
        i += 1
    # drop PENDING markers, keep last per path
    seen = {}; order = []
    for path, t, n, b in rows:
        if t.endswith('-PENDING'): continue
        if path not in seen: order.append(path)
        seen[path] = (t, n, b)
    return [(pp, seen[pp][0], seen[pp][1], seen[pp][2]) for pp in order]

TEXTABLE = {'TEXT','long','shor','bool','doub','sing','date','comp','addr','fixe','byte','ostp','extd','char','tokn','dir ','enum','type','sing'}
OUTLINEY = {'optx','mbar','wptx'}
BINARY   = {'list','reco','obj ','**bi','PICT','fss ','alis','ptr ','hdl ','pict','data','cRGB','qdrt','QDpt','exte'}

def cls(t):
    if t == 'tabl': return 'structure'
    if t == 'scpt': return 'script'
    if t in OUTLINEY: return 'outline-shaped'
    if t in TEXTABLE: return 'textable-scalar'
    if t.startswith('ERR') or t in ('MAXDEPTH','SKIPPED-known-crash'): return 'error/skipped'
    if t == '????': return 'empty/undefined'
    if t in BINARY: return 'binary'
    return 'other/unknown'
