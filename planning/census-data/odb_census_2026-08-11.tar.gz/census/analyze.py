import sys, os, statistics
from collections import defaultdict

# Treat everything as bytes; decode only with latin-1 (byte-preserving) to avoid
# UTF-8 round-trip corruption of MacRoman text (#880 class trap).
def load(path):
    with open(path, 'rb') as f:
        raw = f.read()
    raw = raw.replace(b'\r\n', b'\n').replace(b'\r', b'\n')
    rows = []
    for line in raw.split(b'\n'):
        if not line.strip():
            continue
        parts = line.split(b'\t')
        if len(parts) != 4:
            rows.append(('MALFORMED', line.decode('latin-1'), 0, 0))
            continue
        p, t, n, b = parts
        try:
            n = int(n); b = int(b)
        except ValueError:
            n, b = -1, -1
        rows.append((p.decode('latin-1'), t.decode('latin-1'), n, b))
    return rows

def dedupe(rows):
    """Drop PENDING markers and keep last observation per path."""
    seen = {}
    order = []
    for p, t, n, b in rows:
        if t.endswith('-PENDING'):
            continue
        if p not in seen:
            order.append(p)
        seen[p] = (t, n, b)
    return [(p, seen[p][0], seen[p][1], seen[p][2]) for p in order]

# Classification for the headline table.
TEXTABLE_SCALARS = {'TEXT','long','shor','bool','doub','sing','date','comp','addr','fixe','byte','ostp','extd','char','tokn','dir '}
OUTLINE_SHAPED   = {'optx','mbar','wptx'}
BINARY_TYPES     = {'list','reco','obj ','**bi','PICT','fss ','alis','ptr ','hdl '}

def classify(t):
    if t == 'tabl': return 'structure'
    if t == 'scpt': return 'script'
    if t in OUTLINE_SHAPED: return 'outline-shaped'
    if t in TEXTABLE_SCALARS: return 'textable'
    if t.startswith('ERR') or t in ('MAXDEPTH','SKIPPED-known-crash','MALFORMED'): return 'error/skipped'
    if t in BINARY_TYPES: return 'binary'
    return 'other/unknown'

def report(name, path):
    rows = dedupe(load(path))
    print('=' * 70)
    print(f'ROOT: {name}   ({len(rows)} values)')
    print('=' * 70)

    hist = defaultdict(int)
    bytes_by_type = defaultdict(int)
    sizes = defaultdict(list)
    for p, t, n, b in rows:
        hist[t] += 1
        if b > 0:
            bytes_by_type[t] += b
            sizes[t].append((b, p))
    print('\n-- TYPE HISTOGRAM --')
    for t, c in sorted(hist.items(), key=lambda x: -x[1]):
        print(f'{t:24s} {c:7d}  bytes={bytes_by_type[t]:10d}  class={classify(t)}')

    print('\n-- SIZE DISTRIBUTION (non-scalar) --')
    for t in ['scpt','optx','wptx','mbar','TEXT','list','reco','PICT']:
        if t in sizes and sizes[t]:
            v = sorted(x[0] for x in sizes[t])
            print(f'{t:6s} count={len(v):6d} total={sum(v):10d} min={v[0]:7d} median={int(statistics.median(v)):7d} max={v[-1]:8d}')

    print('\n-- CLASS SUMMARY (% of values / % of bytes) --')
    cls_c = defaultdict(int); cls_b = defaultdict(int)
    for p, t, n, b in rows:
        c = classify(t); cls_c[c] += 1
        if b > 0: cls_b[c] += b
    tot_c = sum(cls_c.values()); tot_b = sum(cls_b.values())
    for c in sorted(cls_c, key=lambda x: -cls_c[x]):
        pv = 100.0*cls_c[c]/tot_c if tot_c else 0
        pb = 100.0*cls_b[c]/tot_b if tot_b else 0
        print(f'{c:16s} {cls_c[c]:7d} ({pv:5.2f}%)   bytes {cls_b[c]:10d} ({pb:5.2f}%)')
    print(f'{"TOTAL":16s} {tot_c:7d}            bytes {tot_b:10d}')

    print('\n-- NON-TEXTABLE SURFACE (binary/outline-shaped/unknown) --')
    nt = [(p,t,n,b) for p,t,n,b in rows if classify(t) in ('binary','outline-shaped','other/unknown')]
    ntc = defaultdict(int)
    for p,t,n,b in nt: ntc[t]+=1
    for t,c in sorted(ntc.items(), key=lambda x:-x[1]): print(f'   {t:10s} {c:6d}')
    print(f'   TOTAL non-textable: {len(nt)}')
    if len(nt) <= 200:
        for p,t,n,b in nt: print(f'      {t:6s} {b:9d}  {p}')
    else:
        print('   -- largest 20 by bytes --')
        for b,t,p in sorted(((b,t,p) for p,t,n,b in nt), reverse=True)[:20]:
            print(f'      {t:6s} {b:9d}  {p}')

    print('\n-- ODDITIES (errors / skips / malformed) --')
    odd = [(p,t,n,b) for p,t,n,b in rows if classify(t)=='error/skipped']
    if not odd: print('   none')
    for p,t,n,b in odd: print(f'   {t:22s} {p}')
    print()
    return rows, hist, cls_c, cls_b

if __name__ == '__main__':
    for nm, pth in [('Virgin.root','/tmp/census/virgin2.tsv'),
                    ('mainResponder.root','/tmp/census/g_mainResponder.tsv'),
                    ('manila.root','/tmp/census/g_manila.tsv')]:
        if os.path.exists(pth):
            report(nm, pth)
