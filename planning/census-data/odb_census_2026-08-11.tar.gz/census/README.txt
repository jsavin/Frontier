ODB VALUE-TYPE CENSUS -- RAW DATA
Generated 2026-08-11 by the census-odb agent.
Source: Frontier @ origin/develop 03d7fe110 (worktree .claude/worktrees/census-odb)

WHAT THIS IS
Complete recursive inventory of every value in the three shipped ODB roots,
produced as decision data for a "text-canonical + binary assets" repo design.
Read ODB_CENSUS_REPORT.txt first -- it is the finished analysis (469 lines).

AUTHORITATIVE RAW DATA (the census proper)
  V.tsv.1 .. V.tsv.12        Virgin.root walk        (11,257 rows emitted)
  MR.tsv.1 .. MR.tsv.5       mainResponder.root walk  (3,596 rows)
  MA.tsv.1                   manila.root walk           (444 rows)
  mac_*.tsv.1                system.macintosh subtree   (282 rows, 6 files)
                             -- recovered separately, see CAVEAT 1

TSV FORMAT: path <TAB> type <TAB> nodes <TAB> bytes
  Parse from the RIGHT (rsplit on tab, 3 splits). Value NAMES legitimately
  contain tab and CR/LF bytes, so left-splitting corrupts ~1,553 Virgin rows.
  `nodes` = sizeOf() = outline node count for scripts, child count for tables.
  `bytes` = sizeOf(string(v)) = text-projection length. -2 = deliberately not
  coerced (list/reco/obj/**bi -- see CAVEAT 2). Tables always report 0 bytes.

ENCODING: treat as BYTES. Decode latin-1 (byte-preserving) only, never UTF-8 --
these roots contain MacRoman text and a UTF-8 round-trip corrupts it (#880 class).

TOOLING
  scripts/walk_chunk.ut   the final crash-safe chunked walker (use this one)
  scripts/walk_safe.ut    prior version -- LOSSY, see CAVEAT 3
  scripts/walk_full.ut    first version -- LOSSY, same bug
  analyze2.py             parser + type classifier
  gen.py                  report generator (reads analyze2.py, emits the report)
  Regenerate: python3 gen.py

CAVEATS -- read before trusting any file here
1. system.macintosh SEGFAULTS (#864) when descended from its parent mid-walk,
   but each of its 6 children walks cleanly in its own process. The mac_*.tsv.1
   files are that recovery; gen.py merges them into the Virgin totals. The
   subtree data is intact -- the crash is session/state-dependent, not data-dependent.
2. string() on a `list` value HARD-ABORTS the interpreter, uncatchable by an
   enclosing try. The walker skips coercion for list/reco/obj/**bi and marks
   them bytes=-2. Repro: system.extensions.odbc.data.dll.macCarbon.rFork
3. file.writeWholeFile(path,data,true) does NOT append -- it TRUNCATES. This
   silently destroyed two earlier full walks. These files are its casualties and
   are EMPTY or PARTIAL -- do not use them as data:
     virgin2.tsv, g_mainResponder.tsv, g_manila.tsv, sys_extensions.tsv,
     sys_macintosh.tsv, ext_odbc.tsv, ext_regex.tsv, probe_sys.tsv,
     virgin_raw.tsv / virgin_lf.tsv (partial first walk, died entering system)
   The sys_*.tsv / ext_*.tsv files that are NON-empty are valid bisection probes
   from the crash hunt, kept as evidence for the bug reports.
4. Virgin emitted 11,257 rows but has 11,255 unique paths: two entries under
   system.verbs.builtins.tcp.im.builtinDrivers.aim.code.util.repl are named with
   the literal bytes 0x0D and 0x0A and collide once names are newline-normalized.
   Not data loss -- a naming collision inherent to the ODB.
5. Byte totals are text-projection sizes, NOT on-disk sizes. `data` blob sizes
   via sizeOf(string()) are approximate.

NOT INCLUDED: copies of Virgin.root / mainResponder.root / manila.root (~40MB).
Reproduce from git at the commit above; all walks used /tmp copies opened with
--lock-opened-roots --skip-startup so the originals were never mutated.
