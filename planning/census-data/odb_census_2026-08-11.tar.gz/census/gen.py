exec(open('/tmp/census/analyze2.py').read())
import statistics
ROOTS = [('V','Virgin.root'),('MR','mainResponder.root'),('MA','manila.root')]
data = {tag: load(tag) for tag,_ in ROOTS}
# Merge system.macintosh: it segfaults when descended from its parent in a long
# session (#864) but each of its 6 children walks cleanly as its own process.
_mac=[]
for _c in ['constants','core','globals','misc','objectModel','required']:
    _mac += load('mac_'+_c)
data['V'] = [r for r in data['V'] if r[1]!='SKIPPED-known-crash'] + _mac
CLASSES = ['script','structure','textable-scalar','outline-shaped','binary','empty/undefined','other/unknown','error/skipped']

print('='*78); print('SUMMARY TABLE'); print('='*78)
for tag,name in ROOTS:
    rows=data[tag]
    cc=defaultdict(int); cb=defaultdict(int)
    for p,t,n,b in rows:
        c=cls(t); cc[c]+=1
        if b>0: cb[c]+=b
    tc=sum(cc.values()); tb=sum(cb.values())
    print(f'\n{name}   values={tc}   measured text bytes={tb}')
    print(f'  {"class":18s} {"count":>7s} {"%val":>7s} {"bytes":>11s} {"%byt":>7s}')
    for c in CLASSES:
        if cc[c]==0 and cb[c]==0: continue
        print(f'  {c:18s} {cc[c]:7d} {100.0*cc[c]/tc:6.2f}% {cb[c]:11d} {(100.0*cb[c]/tb if tb else 0):6.2f}%')

for tag,name in ROOTS:
    rows=data[tag]
    print('\n'+'='*78); print(f'ROOT: {name}  ({len(rows)} values)'); print('='*78)
    hist=defaultdict(int); byt=defaultdict(int); sizes=defaultdict(list)
    for p,t,n,b in rows:
        hist[t]+=1
        if b>0: byt[t]+=b; sizes[t].append(b)
    print('\n-- TYPE HISTOGRAM --')
    print(f'  {"type":10s} {"count":>7s} {"bytes":>11s}  class')
    for t,c in sorted(hist.items(), key=lambda x:-x[1]):
        print(f'  {t:10s} {c:7d} {byt[t]:11d}  {cls(t)}')
    print(f'  {"TOTAL":10s} {sum(hist.values()):7d} {sum(byt.values()):11d}')
    print('\n-- SIZE DISTRIBUTION --')
    print(f'  {"type":8s} {"count":>7s} {"total":>10s} {"min":>7s} {"median":>8s} {"max":>9s}')
    for t in sorted(sizes, key=lambda x:-sum(sizes[x])):
        v=sorted(sizes[t])
        print(f'  {t:8s} {len(v):7d} {sum(v):10d} {v[0]:7d} {int(statistics.median(v)):8d} {v[-1]:9d}')
    nt=[(p,t,n,b) for p,t,n,b in rows if cls(t) in ('binary','outline-shaped','empty/undefined','other/unknown')]
    print(f'\n-- NON-TEXTABLE SURFACE ({len(nt)} values) --')
    ntc=defaultdict(int); ntb=defaultdict(int)
    for p,t,n,b in nt:
        ntc[t]+=1
        if b>0: ntb[t]+=b
    for t,c in sorted(ntc.items(), key=lambda x:-x[1]):
        print(f'   {t:8s} count={c:5d} bytes={ntb[t]}  ({cls(t)})')
    if len(nt)<=200:
        print('   -- full list (by size desc) --')
        for p,t,n,b in sorted(nt, key=lambda x:-x[3]):
            print(f'      {t:6s} {b:8d}  {p}')
    else:
        print('   -- largest 20 by bytes --')
        for p,t,n,b in sorted(nt, key=lambda x:-x[3])[:20]:
            print(f'      {t:6s} {b:8d}  {p}')
        print('   -- representative paths per type --')
        for t in sorted(ntc, key=lambda x:-ntc[x]):
            for e in [p for p,tt,n,b in nt if tt==t][:3]:
                print(f'      {t:6s} {e}')
    odd=[(p,t,n,b) for p,t,n,b in rows if cls(t)=='error/skipped']
    print(f'\n-- ODDITIES ({len(odd)}) --')
    for p,t,n,b in odd: print(f'   {t:24s} {p}')
    if not odd: print('   none')

print('\n'+'='*78); print('TYPE PRESENCE ACROSS ROOTS'); print('='*78)
allt=set()
for tag,_ in ROOTS: allt |= set(t for p,t,n,b in data[tag])
print(f'  {"type":10s} {"Virgin":>8s} {"mainResp":>9s} {"manila":>8s}   class')
for t in sorted(allt):
    c=[sum(1 for p,tt,n,b in data[tag] if tt==t) for tag,_ in ROOTS]
    print(f'  {t:10s} {c[0]:8d} {c[1]:9d} {c[2]:8d}   {cls(t)}')
