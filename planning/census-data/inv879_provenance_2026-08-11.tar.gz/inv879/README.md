# Issue #879 Provenance Investigation — Archived Artifacts

Archived 2026-08-11. Investigation of WHEN and HOW the 12 non-compiling scripts in
`databases/Virgin.root` broke. Companion to issues #879 and #866.

Investigation worktree was `.claude/worktrees/inv-879-provenance`, detached at
`03d7fe110`. CLI built with `make -C frontier-cli CC=/usr/bin/clang` (bare clang
picks a nonexistent SDK).

## Headline result

Of the 12 scripts that fail `script.compile` in place:

| Class | Count | Scripts |
|-------|-------|---------|
| Corruption we caused, repairable from .ut mirror | 1 | `userland.cleanRoot` |
| Corruption we caused, repairable by plain reinstall | 2 | `webBrowser.openUrl`, `string.isValidUrl` |
| Pre-existing legacy doc outlines that never compiled | 2 | `Filemaker.examples.transactions`, `userland.oldstuff.Frontier3toAretha` |
| Build-gap kernel glue stubs (source pristine) | 6 | `string.nthChar`, `quickTime.isPlaying/.open/.play/.stop`, `window.quickTime` |
| Deliberate test fixture | 1 | `webserver.data.cgis.samples.syntaxError` |

Both corrupting passes are already fixed. There is no live corruption risk.

## Method notes — READ BEFORE REUSING THESE SCANNERS

Three traps produced false results during this investigation. Any future
verification sweep should account for all three, and should be validated against
a known-positive control before a green result is believed.

### 1. `string(adr^)` fails on exactly the damaged scripts

The dereference form `string(adrSub^)` raises "Can't coerce to an address..."
on LF-single-node scripts — precisely the class being hunted. The indexed form
`string(adrTable^[name])` works. A bare `try`/`else` around the read silently
yields `""`, so the damaged script reads as clean and the sweep under-reports
the very damage it is looking for.

My first three LF scans returned a FALSE ZERO for this reason.

### 2. `string.mid (s, k, sizeof (s))` overruns

Must be `string.mid (s, k, sizeof (s) - k + 1)`. The overrunning form throws,
and inside a `try`/`else` that silently becomes a zero count.

### 3. MacRoman must never round-trip through UTF-8

`0xC7` is the intact MacRoman `«` guillemet in legacy UserLand source — it is
NOT mangling. The #866 false diagnosis came from decoding it as UTF-8. All
source extraction here is done via `file.writeWholeFile` from inside UserTalk
(never through the JSON protocol result), then read back as raw bytes in
Python with `mac_roman` decode used for display only.

### Other UserTalk gotchas hit

- `defined(adr^)` returns false for script values — use `typeof(adr^) == scripttype`.
- `@[string]` does not resolve dotted paths; use a recursive walker instead.
- `continue` is not valid UserTalk; restructure with nested conditionals.
- `try {...};` `else {...}` — a semicolon before `else` is a syntax error.
- Each protocol request runs in a fresh context, so scratch tables do not persist
  between `script/eval` calls.
- `odb/set` cannot write script values at all ("Unknown type: script").
- Protocol op is `script/eval` with `params.expression`; requests need an `id`.

## Findings per script

### userland.cleanRoot — ours

First broken at `2ecf66777` (2026-05-07, PR #581, db.compactDatabase + slim
Virgin.root 99MB->11MB). Compiles at `66a523d69`, broken at `2ecf66777`.

Signature: brace injection. Braces 39/39 -> 121/121. Source 7828 -> 11265 bytes.
Line 1 becomes `" {//run this script to clean up the root for release"`. Comment
text swallowed after injected close-braces, e.g. `"};//DW 11/5/97 Frontier 5.0a11"`.
Guillemets converted to `//`, high-bit byte count 52 -> 0. Bisect: first failure
at line 1, "Internal error -- unexpected opcode encountered (0)".

Causal chain, proven by mirror brace counts:

- `13103f032^` mirror = 39/39 braces, 113 UTF-8 guillemets
- `13103f032` mirror = 39/39 braces, 0 guillemets (the sed alone did NOT inject braces)
- `2ecf66777` mirror = 57/57 braces

So the injection happened on the ODB import round-trip during #581, not in the
bulk `«` -> `//` replacement. Note that `13103f032`'s own commit message asserts
"No functional change — .ut files are read-only reference artifacts, not packed
into .root databases" — that premise was violated seven weeks later by #581.

### webBrowser.openUrl + string.isValidUrl — ours

Both frozen at the same md5 since birth; the LF form was present at creation and
never modified after:

- `webBrowser.openUrl` md5 9d0747fc8dec, 1017 bytes, CR=0 LF=26, 1 node
- `string.isValidUrl` md5 8a462adc9835, 602 bytes, CR=0 LF=15, 1 node

Producing commit: `abb463492` (2026-03-23, PR #486, Modernize startup flow) —
the same commit that AUTHORED both scripts. Both carry `//3/21/26 by JES` headers.

Mechanism is a bootstrap ordering trap. `isoutlinetext()`
(`Common/source/opstructure.c:2685`) decides split-vs-flat by searching ONLY for
CR, so LF-only text looks flat and lands in one node with literal `\n` bytes
embedded. PR #486 added LF->CR normalization inside `script.newScriptObject` —
but that fix lives in the ODB script being installed during the same PR, so the
two new scripts went in through the un-normalized path.

The C-level fix came 26 days later: `9accff81b` (2026-04-18, PR #542,
"op.insert normalizes LF/CRLF to CR before outline split"), adding
`opnormalizelineendings_cr()` called from `opinserthandle_ctx` before
`isoutlinetext()`. That commit message describes this exact damage.

Damage window: 2026-03-23 (#486) to 2026-04-18 (#542). Both victims were
installed inside it and never reinstalled since.

Ruled out as vectors (tested, negative): pre-#486 `script.newScriptObject` alone
does not reproduce (readback 597 bytes, CR=14, compiles) because today's C layer
normalizes; direct assignment to a script value is rejected; `odb/set` cannot
write scripts.

Status today: FIXED. Feeding the raw LF source through the current installer
yields 597 bytes CR=14 LF=0 and compiles. Reinstall repairs both — #879's claim
"reinstall does NOT repair them" is FALSE for these two.

### Filemaker.examples.transactions + userland.oldstuff.Frontier3toAretha — NOT ours

Byte-identical across the pristine v6 ancestor, the earliest committed
Virgin.root, the #581 version, and current:

- `transactions` md5 c1e861f3bd5c, 4228 bytes, 93 CR, 52 guillemets, 16/16 braces
- `Frontier3toAretha` md5 511242304488, 820 bytes, 31 CR, 5 guillemets, 7/7 braces

`transactions` first fails at line 10, a bare separator
`"----------...----;"` which is not valid UserTalk (line 64 is a second one).
`Frontier3toAretha` line 1 is bare prose,
`"turns a Frontier 3.0.3 database into an Aretha database;"`.

Both are documentation/utility outlines that were never compiling verbs. They do
not falsify the maintainer's attestation that UserLand never shipped a
non-compiling verb.

### The 6 kernel glue stubs — build gap, not damage

Control comparison on current Virgin.root, byte-identical glue shape:

| Script | Source | Result |
|--------|--------|--------|
| `string.upper` | `on upper (s) { \| kernel (string.upper)}` | COMPILES |
| `string.lower` | `on lower (s) { \| kernel (string.lower)}` | COMPILES |
| `string.nthField` | `on nthField (s, chdelim, n) { \| kernel (string.nthField)}` | COMPILES |
| `string.nthChar` | `on nthChar (s, n) { \| kernel (string.nthChar)}` | FAILS |

All six stubs are byte-identical between the pristine v6 ancestor and current
Virgin.root, so the stored source never changed. The failure is dispatch-side.

Note for whoever fixes it: `nthchar` IS present in
`Common/resources/Mac/kernelverbs.r:557` and `nthcharfunc` has a live case
handler at `Common/source/stringverbs.c:1629`. This is a name-table / dispatch
resolution gap in the headless build, not a missing implementation, so the fix
is likely cheap. Not chased further — out of scope for archaeology.

## Corpus-wide scans (current Virgin.root)

Embedded-LF scan (`lfscan6.ut`, the validated version):
`CHECKED=3499` (scripttype + outlinetype), `WITH_LF=2`, `EMPTY=2`. The two hits
are exactly `webBrowser.openUrl` (26) and `string.isValidUrl` (15), matching the
byte counts. No other stored node in the DB carries embedded LF.

Brace-injection marker scan (`deep2.ut`), counting occurrences of `};//`:
`CHECKED=3359`, `DAMAGED=15`. `cleanRoot` has 20 occurrences; 14 other scripts
have 1 each and STILL COMPILE, so they are invisible to a compile-based sweep:

```
20  system.verbs.builtins.userland.cleanRoot
 1  system.menus.handlers.repl.help / .clear / .keycodes / .exit
 1  system.verbs.builtins.op.newOutlineObject
 1  system.verbs.builtins.script.newScriptObject
 1  system.verbs.builtins.html.dialog.draw
 1  system.verbs.builtins.soap.rpc.client
 1  system.verbs.builtins.xml.rss.formatDrivers.feed.compile
 1  system.verbs.apps.Manila.windowTypes.dialogs.wizard.callbacks.customRenderer/.getValue/.setValue
 1  system.verbs.apps.xmlStorageSystem.nodeTypes.user.data.dialogs.wizard.callbacks.getValue/.setValue
```

That damage is cosmetic-but-real: comment nesting was converted into brace pairs
that happen to balance, so the scripts compile and behave correctly, but the
stored outline no longer matches the authored comment hierarchy. Note that
`script.newScriptObject` and `op.newOutlineObject` — the install verbs
themselves — carry the damage.

## Files

### Harness

- `mkreq.py` — wraps a `.ut` file into a `script/eval` NDJSON protocol request
- `run_sweep.sh` — runs `sweep1.ut` against a given .root and parses the result
- `sweep1.ut` — recursive compile sweep; the primary measurement
- `sweep.ut` — first draft of the walker (superseded by `sweep1.ut`)

### Scanners

- `lfscan6.ut` — VALIDATED embedded-LF scan. Use this one.
- `lfscan.ut` .. `lfscan5.ut` — earlier attempts, retained to document the false
  zeros. `lfscan`/`lfscan2`/`lfscan3` use the failing deref read; `lfscan4`/
  `lfscan5` fix the read but still miscount. Do not reuse without reading the
  method notes above.
- `deep2.ut` — brace-injection marker scan (`};//` occurrences). Authoritative.
- `deep_scan.ut`, `brace_scan.ut` — earlier/coarser brace scans
- `probe_countlf.ut`, `probe_lf2.ut`, `probe_lf3.ut`, `probe_reach.ut` —
  isolation probes used to find traps 1 and 2

### Byte-exact extracted sources

Current Virgin.root, extracted via `file.writeWholeFile` (never UTF-8 round-tripped):

- `cur_cleanRoot.txt`, `cur_openUrl.txt`, `cur_isValidUrl.txt`,
  `cur_transactions.txt`, `cur_Frontier3toAretha.txt`

Across the cleanRoot break boundary:

- `cr-66a523d69.txt` (before, 7828 bytes, 39/39 braces)
- `cr-2ecf66777.txt` (after, 11265 bytes, 121/121 braces)

The two legacy examples across four DB versions (all byte-identical):

- `leg-{v6test,v-fe0d193bc,vr-2ecf66777,base-Virgin}_{transactions,Frontier3toAretha}.txt`

The LF pair across eight DB versions (all byte-identical):

- `lf-{vr-abb463492,vr-5886cff96,vr-422a60113,vr-9290c2735,vr-2ecf66777,vr-ce9d5db60,vr-2ce3d8491,base-Virgin}_{openUrl,isValidUrl}.txt`

Mirror snapshots across the guillemet-replacement boundary:

- `mir-before13.ut` (39/39 braces, 113 UTF-8 guillemets)
- `mir-after13.ut` (39/39 braces, 0 guillemets)
- `mir-at2ecf.ut` (57/57 braces)

Round-trip stability evidence (today's installer):

- `gen1.txt`, `gen2.txt` — two generations, both 7837 bytes, no brace growth
- `lf_readback.txt`, `repro_old.txt` — 597-byte CR-form results

Spot-checks of silently damaged but compiling scripts:

- `spot_nso.txt` (`script.newScriptObject`), `spot_help.txt` (`repl.help`),
  `spot_soap.txt` (`soap.rpc.client`)

### Test scripts

`bisect.ut`, `bisect2.ut` (first-failing-line bisection), `reinstall*.ut`,
`mirror_test.ut`, `live_test.ut`, `lf_test.ut`, `bootstrap_repro.ut`,
`direct_assign.ut`, `kernel_ctrl.ut`, `kernel_hist.ut`, `targeted*.ut`,
`dump*.ut`, `ex*.ut`, `spot.ut`, `probe.ut`, `tofile.ut`, `hexdump.ut`,
`odbset*.ndjson` (negative results — `odb/set` cannot write scripts).

## Excluded: historical .root copies

The `*.root` files are excluded from this archive — each is multi-MB and
byte-reproducible from git. Regenerate with:

```bash
git show <sha>:databases/Virgin.root > /tmp/inv879/vr-<sha>.root
```

SHAs used, chronological (all `databases/Virgin.root` unless noted):

```
fe0d193bc  2026-02-20  first commit where databases/Virgin.root exists
abb463492  2026-03-23  #486 Modernize startup flow  <- openUrl/isValidUrl born broken
5886cff96  2026-03-23  glue script trailing-newline fix
422a60113  2026-03-24  string.trimWhiteSpace in newScriptObject
9290c2735  2026-03-24  #491 Clean Virgin.root
0d212e3a0  2026-04-09  #529 Batch P1 fixes
66a523d69  2026-04-26  #549 last version where cleanRoot COMPILES
2ecf66777  2026-05-07  #581 db.compactDatabase  <- cleanRoot breaks here
2449e1f4c  2026-05-07  #582 slash-menu palette
9b7b54b79  2026-05-07  #583 slash commands to menubar
93c1985a1  2026-05-07  #599 collapse hybrid slash dispatch
1a38457bb  2026-05-12  #621 inline nested block round-trip fix
d78588b87  2026-05-30  #674 palette cascade UX
3bedd5889  2026-05-31  #683 window-event callback bridge
beb166632  2026-05-31  #688 menu content via windowTypes manifest
ce9d5db60  2026-06-02  #693 re-export .ut corpus as UTF-8/LF
2ce3d8491  2026-08-10  #856 Unit 3.1 HTTP page
21d33d2fd  2026-08-10  #875 startupScript error guards
```

The pristine v6 ancestor is a different path — `databases/Frontier.root` at
`5002c10ca` (2025-08-09, header `00 06`). Reproduce the migrated form with:

```bash
git show 5002c10ca:databases/Frontier.root > /tmp/inv879/v6test.root
./frontier-cli/frontier-cli --migrate /tmp/inv879/v6test.root
```

Migrating it and sweeping shows the same 9 pre-existing failures, which is how
migration was ruled out as a cause.

Note `git log --follow -- databases/Virgin.root` traces through a rename into
`databases/Frontier.root`; the early SHAs it reports do not contain a file at
the `Virgin.root` path.

## Reproducing the primary measurement

```bash
git worktree add .claude/worktrees/inv-879 --detach 03d7fe110
cd .claude/worktrees/inv-879
make -C frontier-cli CC=/usr/bin/clang
cp databases/Virgin.root /tmp/inv879/base-Virgin.root
./run_sweep.sh /tmp/inv879/base-Virgin.root
```

Expect `VISITED=3359` and 12 BROKEN lines. All DB work must be done on /tmp
copies with `--lock-opened-roots --skip-startup`; never open canonical files
read-write.
