import json, sys
src = open(sys.argv[1]).read()
print(json.dumps({"id":1,"op":"script/eval","params":{"expression":src}}))
