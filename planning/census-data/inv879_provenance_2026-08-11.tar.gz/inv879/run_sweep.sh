#!/bin/bash
DB="$1"
cd /Users/jake/dev/jsavin/Frontier/.claude/worktrees/inv-879-provenance
python3 /tmp/inv879/mkreq.py /tmp/inv879/sweep1.ut | ./frontier-cli/frontier-cli --system-root "$DB" --protocol --skip-startup --lock-opened-roots 2>/dev/null | tail -1 | python3 -c "
import json,sys
raw=sys.stdin.read().strip()
try:
  d=json.loads(raw); print(d.get('result',{}).get('value',str(d)).replace('\r','\n'))
except Exception as ex: print('PARSE_FAIL', ex, raw[:300])"
